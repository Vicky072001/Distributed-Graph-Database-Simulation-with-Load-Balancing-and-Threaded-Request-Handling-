#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N 30
struct shmseg
{
    int n;
    int adj[N][N];
};
struct shmseg graph;

int siz;
int dres[N];

int idx;

void dfs(int s, int p)
{
    int is_leaf = 1;
    for (int i = 0; i < graph.n; ++i)
    {
        if (i != p && graph.adj[s][i] == 1)
        {
            dfs(i, s);
            is_leaf = 0;
        }
    }
    if (is_leaf == 1)
    {
        dres[siz] = s + idx;
        siz++;
    }
}

int lsiz[N];
int bres[N][N];

void bfs(int src)
{
    int queue[N];
    int vis[N] = {0};
    int l = 0, r = 0;
    vis[src] = 1;
    queue[r] = src;
    r++;
    int level = 0;
    while (l < r)
    {
        int lcur = l, rcur = r;
        for (int i = lcur; i < rcur; ++i)
        {
            int s = queue[i];
            bres[level][lsiz[level]] = s + idx;
            lsiz[level]++;
            siz++;
            for (int j = 0; j < graph.n; ++j)
            {
                if (graph.adj[s][j] == 1 && !vis[j])
                {
                    vis[j] = 1;
                    queue[r] = j;
                    r++;
                }
            }
        }
        l = rcur;
        level++;
    }
}

int main()
{
    printf("Enter 0 for 0-based indexing and 1 for 1-based indexing: ");
    scanf("%d", &idx);

    int op_no;
    printf("Enter Operation Number (3 for DFS, 4 for BFS): ");
    scanf("%d", &op_no);

    if (op_no != 3 && op_no != 4)
    {
        perror("Operataion Number must be 3 or 4");
        exit(1);
    }

    char filename[10];
    printf("Enter Graph File Name: ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "r+");
    if (fp == NULL)
    {
        perror("fopen in checker");
        exit(1);
    }
    fscanf(fp, "%d", &graph.n);
    for (int i = 0; i < graph.n; ++i)
    {
        for (int j = 0; j < graph.n; ++j)
        {
            fscanf(fp, "%d", &graph.adj[i][j]);
        }
    }
    fclose(fp);

    int s;
    printf("Enter starting vertex: ");
    scanf("%d", &s);
    s -= idx;


    int op[N];
    if (op_no == 3)
    {
        dfs(s, -1);
        printf("Output must contain %d integers\n", siz);
        for (int i = 0; i < siz; ++i)
        {
            scanf("%d", &op[i]);
        }
        int match[N] = {0};
        for (int i = 0; i < siz; ++i)
        {
            int found = 0;
            for (int j = 0; j < siz; ++j)
            {
                if (op[i] == dres[j])
                {
                    found = 1;
                    if (match[j] == 1)
                    {
                        printf("FAIL: %d was matched twice\n", dres[j]);
                        exit(1);
                    }
                    match[j] = 1;
                }
            }
            if (found == 0)
            {
                printf("FAIL: %d was not matched\n", op[i]);
                exit(1);
            }
        }
        printf("SUCCESS\n");
    }
    else
    {
        bfs(s);
        printf("Output must contain %d integers\n", siz);
        for (int i = 0; i < siz; ++i)
        {
            scanf("%d", &op[i]);
        }
        int done = 0;
        for (int level = 0; lsiz[level] != 0; ++level)
        {
            int match[N] = {0};
            for (int i = done; i < done + lsiz[level]; ++i)
            {
                int found = 0;
                for (int j = 0; j < lsiz[level]; ++j)
                {
                    if (op[i] == bres[level][j])
                    {
                        found = 1;
                        if (match[j] == 1)
                        {
                            printf("FAIL: %d was matched twice at level %d\n", bres[level][j], level);
                            exit(1);
                        }
                        match[j] = 1;
                    }
                }
                if (found == 0)
                {
                    printf("FAIL: %d was not matched at level %d\n", op[i], level);
                    exit(1);
                }
            }
            done += lsiz[level];
        }
        printf("SUCCESS\n");
    }
}